﻿INSERT INTO dbo.users (USERNAME, PASSWORD, FIRST_NAME, LAST_NAME, AGE, EMAIL, STATE) VALUES ('bob123', 'bob123', 'Bob', 'Bobbert', '22', 'bob123@bob.com', 'arizona')

select * from dbo.users