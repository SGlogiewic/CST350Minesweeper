﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CST350Milestone.Models;
using CST350Milestone.Services.Data;

namespace CST350Milestone.Services.Business
{
    public class UserBusinessService
    {
        UserDataService uds = new UserDataService();

        //login method
        public bool loginUser(UserModel user)
        {
            return uds.authenticate(user);
        }

        //register method
        public bool createUser(UserModel user)
        {
            return uds.createUser(user);
        }
    }
}
