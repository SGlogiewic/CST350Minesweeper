﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CST350Milestone.Models
{
    public class GameBoard
    {
        public Random rd = new Random();

        //Properties of the game board
        public int size { get; set; }

        public int gameLevel { get; set; }

        public List<ButtonModel> buttons { get; set; }

        public ButtonModel[,] grid { get; set; }

        public GameBoard(int size)
        {
            //Starts the gameboard's properties
            this.size = size;
            this.gameLevel = 10;
            buttons = new List<ButtonModel>();

            grid = new ButtonModel[size, size];
            int index = 0;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    grid[i, j] = new ButtonModel();
                    grid[i, j].id = index;
                    grid[i, j].live = IsBomb(gameLevel);
                    grid[i, j].row = i;
                    grid[i, j].column = j;
                    index++;
                }
            }
            //Set the bomb buttons on the board
            SetBombNeighborsToButtons();
            //Initiate the button list buttons 
            for (int i = 0; i < Math.Pow(size, 2); i++)
            {
                ButtonModel btn = new ButtonModel();
                buttons.Add(btn);
            }
            //Copy items from 2D array into the button list buttons
            int idx = 0;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    buttons[idx] = grid[i, j];
                    idx++;
                }
            }
        }

        //Determines if the ramdom number is less than or equals the game level, that button is a bomb. Only one level rn.
        public bool IsBomb(int gameLevel)
        {
            int number = rd.Next(0, 100);
            return number <= gameLevel;
        }

        public void SetBombNeighborsToButtons()
        {
            //Copy the bombs neighor from 2D array back the buttons list.
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    grid[i, j].neighbors = CalculateLiveNeighbors(i, j);
                }
            }
        }
        public int CalculateLiveNeighbors(int row, int column)
        {
            //Shows how many live neightbors a cell has
            int selfCellLive = 0;
            if (grid[row, column].live == true)
                selfCellLive = selfCellLive + 1;
            //Sums up the neighbors of the cell.
            return CountHorizontal(row, column) + CountVertical(row, column) + CountPrimary(row, column) + CountSub(row, column) + selfCellLive;
        }
        public int CountHorizontal(int row, int column)
        {   
            int liveNeighbors = 0;
            if (column + 1 < size)
            {
                if (grid[row, column + 1].live)
                    liveNeighbors++;
            }
       
            if (column - 1 >= 0)
            {
                if (grid[row, column - 1].live)
                    liveNeighbors++;
            }
            return liveNeighbors;
        }

        public int CountVertical(int row, int column)
        {
            int liveNeighbors = 0;
         
            if (row - 1 >= 0)
            {
                if (grid[row - 1, column].live)
                    liveNeighbors++;
            }
            
            if (row + 1 < size)
            {
                if (grid[row + 1, column].live)
                    liveNeighbors++;
            }
            return liveNeighbors;
        }

        public int CountPrimary(int row, int column)
        {
            //Check and count neighbor on the below left, wont't count if the neighbor is out of bound.
            int liveNeighbors = 0;
            if (!(row - 1 < 0 || column + 1 >= size))
            {
                if (grid[row - 1, column + 1].live)
                {
                    liveNeighbors++;
                }
            }

            //Check and count neighbor on the above right, wont't count if the neighbor is out of bound.
            if (!(row + 1 >= size || column - 1 < 0))
            {
                if (grid[row + 1, column - 1].live)
                {
                    liveNeighbors++;
                }
            }

            return liveNeighbors;
        }

        public int CountSub(int row, int column)
        {
            //Check and count neighbor on the above left, wont't count if the neighbor is out of bound.
            int liveNeighbors = 0;
            if (!(row - 1 < 0 || column - 1 < 0))
            {
                if (grid[row - 1, column - 1].live)
                {
                    liveNeighbors++;
                }
            }
            //Check and count neighbor on the below right, wont't count if the neighbor is out of bound.
            if (!(size <= row + 1 || size <= column + 1))
            {
                if (grid[row + 1, column + 1].live)
                {
                    liveNeighbors++;
                }
            }
            return liveNeighbors;
        }

        public List<int> GetChangedButton(int row, int colm)
        {
            List<int> idArr = new List<int>();
            FloodFill(row, colm, idArr);
            return idArr;
        }

        public void FloodFill(int row, int colm, List<int> idArr)
        {
            //If the cell is within the board
            if (IsSafe(row, colm))
            {
                //Repeat until the neighbor is next to the live cells
                if (grid[row, colm].neighbors == 0)
                {
                    //Set cell as is visited
                    grid[row, colm].isVisited = 1;
                    idArr.Add(grid[row, colm].id);
                    //Using recursion to check the cell on the left
                    if (IsSafe(row, colm - 1) && grid[row, colm - 1].isVisited == 0)
                    {
                        //Repeat recursion with the cell shift left one unit
                        FloodFill(row, colm - 1, idArr);
                    }
                }
            }
            //If the cell is within the board
            if (IsSafe(row, colm))
            {
                //Repeat until the neighbor is next to the live cells
                if (grid[row, colm].neighbors == 0)
                {
                    //Set cell as is visited
                    grid[row, colm].isVisited = 1;
                    idArr.Add(grid[row, colm].id);
                    //Using recursion to check the cell on the right
                    if (IsSafe(row, colm + 1) && grid[row, colm + 1].isVisited == 0)
                    {
                        //Repeat recursion with the cell shift right one unit
                        FloodFill(row, colm + 1, idArr);
                    }
                }
            }
            //If the cell is within the board
            if (IsSafe(row, colm))
            {
                //Repeat until the neighbor is next to the live cells
                if (grid[row, colm].neighbors == 0)
                {
                    //Set cell as visited
                    grid[row, colm].isVisited = 1;
                    idArr.Add(grid[row, colm].id);
                    //Using recursion to check the cell on the top
                    if (IsSafe(row - 1, colm) && grid[row - 1, colm].isVisited == 0)
                    {
                        //Repeat recursion with the cell shift up one unit
                        FloodFill(row - 1, colm, idArr);
                    }
                }
            }
            //If the cell is within the board
            if (IsSafe(row, colm))
            {
                //Repeat until the neighbor is next to the live cells
                if (grid[row, colm].neighbors == 0)
                {
                    //Set cell as is visited
                    grid[row, colm].isVisited = 1;
                    idArr.Add(grid[row, colm].id);
                    //Using recursion to check the cell on the bottom
                    if (IsSafe(row + 1, colm) && grid[row + 1, colm].isVisited == 0)
                    {
                        //Repeat recursion with the cell shift down one unit
                        FloodFill(row + 1, colm, idArr);
                    }
                }
            }
        }

        public bool IsSafe(int r, int c)
        {
            bool safe = true;
            if (r < 0 || c < 0 || r > size - 1 || c > size - 1)
            {
                return false;
            }
            return safe;
        }
    }
}
